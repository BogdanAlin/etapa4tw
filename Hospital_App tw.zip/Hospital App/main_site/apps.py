from django.apps import AppConfig


class MainSiteConfig(AppConfig):
    name = 'main_site'
